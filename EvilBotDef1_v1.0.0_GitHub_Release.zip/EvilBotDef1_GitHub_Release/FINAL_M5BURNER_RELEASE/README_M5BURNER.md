# EvilBotDef1 - M5Burner Package

## 🛡️ Little Parasite Portal Killer for M5Burner

This package contains the **EvilBotDef1** firmware ready for M5Burner community distribution.

### 📦 **Package Contents:**
- `EvilBotDef1_ParasitePortalKiller.bin` - Complete merged firmware (bootloader + partitions + app)
- `manifest.json` - M5Burner metadata and feature description
- `README_M5BURNER.md` - This documentation

### 🚀 **Installation via M5Burner:**
1. Open M5Burner application
2. Connect AtomS3 device via USB
3. Load this .bin file 
4. Select ESP32-S3 chip type
5. Flash to device
6. **Done!** Device automatically starts in Defender Mode

### 🎯 **What It Does:**
- **Boots directly into portal hunting mode** (no setup required)
- **Scans every 15 seconds** for suspicious open WiFi networks  
- **Automatically connects and attacks** detected evil portals
- **Sends 300 spam requests** per attack (50 bursts × 6 endpoints)
- **Adorable parasite face** shows hunting/attacking/victory expressions

### 🤖 **The Little Parasite:**
- **Cute M5Avatar face** with multiple expressions 
- **Gets suspicious** when scanning for threats
- **Gets angry** when attacking evil portals
- **Spins happily** when portals are destroyed
- **Reacts to movement** - shake it and it gets pissed

### ⚡ **Technical Specs:**
- **Platform:** ESP32-S3 (M5Stack AtomS3)
- **Flash Size:** 872KB firmware + bootloader/partitions
- **Memory Usage:** RAM: 14.3%, Flash: 26.1%
- **Libraries:** M5Unified, M5GFX, M5Stack-Avatar
- **Serial Debug:** 115200 baud for monitoring

### 🛡️ **Defense Strategy:**
**AGGRESSIVE MODE:** Targets ANY open WiFi as potentially dangerous
- Real legitimate businesses should use WPA2/WPA3 protection
- Open networks are prime targets for evil portal attacks
- Protects innocent users from credential harvesting

### 💀 **Attack Method:**
**Enhanced KILLERBS1 Technique:**
- **Credentials:** "Caught Ya Slippin" / "Ya Damn Fool"
- **Endpoints:** /login, /post, /creds, /ssid, /, /captive
- **Volume:** 50 attacks × 6 endpoints = 300 spam requests
- **Timing:** 500ms between attacks (overwhelming speed)
- **Persistence:** Up to 30 connection retry attempts

### 🚨 **Legal Notice:**
**FOR DEFENSIVE SECURITY PURPOSES ONLY**

This device is designed to protect innocent users from evil portal credential harvesting attacks by overwhelming malicious captive portals with fake data. Use responsibly and in compliance with local laws.

---
**Version:** EvilBotDef1 v1.0.0  
**Status:** ✅ User-Confirmed Working  
**Created:** October 26, 2024  
**Authors:** DefenseTeam & 7h30th3r0n3