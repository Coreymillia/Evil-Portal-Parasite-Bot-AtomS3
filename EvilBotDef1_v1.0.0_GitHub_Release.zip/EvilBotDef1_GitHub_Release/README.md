# 🛡️ EvilBotDef1 - Little Parasite Portal Killer

## **The Adorable Evil Parasite That Fights Back Against Evil Portals**

<div align="center">

![Version](https://img.shields.io/badge/Version-1.0.0-brightgreen)
![Platform](https://img.shields.io/badge/Platform-ESP32--S3-blue)
![Device](https://img.shields.io/badge/Device-M5Stack%20AtomS3-orange)
![Status](https://img.shields.io/badge/Status-Working%20✅-success)

*An adorable M5Avatar parasite that automatically hunts and destroys evil WiFi portals*

</div>

---

## 🎯 **What Is This?**

**EvilBotDef1** is a cute little parasite that lives on your M5Stack AtomS3 and **automatically protects innocent users** from evil portal attacks. It features an adorable animated face that shows different expressions while hunting for malicious captive portals.

When it detects suspicious open WiFi networks, the little parasite:
- Gets **angry** and **connects** to the evil portal
- **Spams 300 fake credentials** to overwhelm the attacker's database  
- **Celebrates victory** with happy spinning animations
- **Protects real users** from having their credentials stolen

---

## 🤖 **The Little Parasite**

### **Adorable M5Avatar Face Features:**
- **😊 Happy** - Normal idle state, cycling through cute expressions
- **🤔 Doubt** - Suspicious look while scanning for threats  
- **😡 Angry** - Attack mode when evil portals detected
- **🎉 Celebration** - Victory spins when portals destroyed
- **😴 Sleepy** - Random cute expression during idle
- **😢 Sad** - When no networks found or connection fails

### **Interactive Personality:**
- **Motion Reactive** - Shake the device and it gets pissed! 
- **Speech Bubbles** - Shows what it's thinking ("Scanning...", "ATTACK!", "Got you!")
- **Expression Cycling** - Automatically changes emotions every 20 seconds
- **Victory Dances** - Spins happily every 50 successful attacks

---

## 🛡️ **Defense Capabilities**

### **🎯 Aggressive Detection:**
- **Auto-scan every 15 seconds** for suspicious networks
- **Targets ALL open WiFi** as potentially malicious
- **Smart filtering** - Skips known safe networks (xfinitywifi, attwifi, etc.)
- **Real-time serial debugging** - Full operational visibility

### **💥 KILLERBS1 Attack Method:**
- **50 spam bursts per portal** = Overwhelming volume
- **6 different endpoints** attacked per burst (/login, /post, /creds, /ssid, /, /captive)
- **300 total fake requests** per evil portal detected
- **Proven credentials** - "Caught Ya Slippin" / "Ya Damn Fool"  
- **500ms attack timing** - Optimal overwhelming speed
- **30 connection retries** - Persistent portal destruction

---

## 🚀 **Quick Start**

### **Option 1: M5Burner (Easiest)**
1. Download `EvilBotDef1_ParasitePortalKiller.bin` from releases
2. Open M5Burner application
3. Connect your AtomS3 via USB
4. Flash the .bin file
5. **Done!** - Device auto-starts in defender mode

### **Option 2: PlatformIO Build**
```bash
git clone [this-repo]
cd EvilBotDef1_GitHub_Release
pio run --environment ATOMS3 --target upload
```

### **Option 3: Arduino IDE**
1. Install required libraries: M5Unified, M5GFX, M5Stack-Avatar
2. Open `Evil-Face-WITH-DEFENDER.ino` 
3. Select ESP32-S3 board
4. Upload to AtomS3

---

## 🏆 **Credits & Attribution**

### **Original Evil-M5 Projects:**
- **[7h30th3r0n3](https://github.com/7h30th3r0n3)** - Creator of the original Evil-M5Core2 and Evil-AtomS3 projects
- **Evil-M5 Community** - For the foundational WiFi security tools and inspiration

### **M5Avatar Library:**
- **[meganetaaan](https://github.com/meganetaaan)** - Creator of the M5Stack-Avatar library for the adorable faces

### **Defense Integration:**
- **DefenseTeam** - Integration of portal defense capabilities with parasite personality
- **Community Testing** - User feedback and operational verification

### **Technical Inspiration:**
- **KILLERBS1** - Inspiration for the effective spam attack methodology
- **WiFi Security Community** - For highlighting the evil portal threat

---

## ⚖️ **Legal & Ethics**

### **🛡️ Defensive Purpose:**
This tool is designed **FOR DEFENSIVE SECURITY PURPOSES ONLY** to protect innocent users from credential harvesting attacks.

### **How It Helps:**
- **Overwhelms evil portals** with fake data to render them useless
- **Protects real users** from accidentally entering real credentials  
- **Educational tool** for understanding captive portal vulnerabilities
- **Security research** for testing portal detection methods

### **Usage Guidelines:**
- ✅ **Use to protect against malicious portals**
- ✅ **Educational and research purposes**
- ✅ **Testing your own security setups**
- ❌ **Do not target legitimate networks**
- ❌ **Comply with local laws and regulations**

---

## 📋 **Technical Specifications**

| Component | Details |
|-----------|---------|
| **Platform** | ESP32-S3 (M5Stack AtomS3) |
| **Flash Usage** | 871KB firmware (26.1% of 8MB) |
| **RAM Usage** | 47KB (14.3% of 327KB) |
| **Libraries** | M5Unified, M5GFX, M5Stack-Avatar |
| **Serial Baud** | 115200 for debugging |
| **Attack Volume** | 300 requests per portal (50 × 6 endpoints) |
| **Scan Interval** | Every 15 seconds |
| **Connection Retries** | Up to 30 attempts per portal |

---

## 📁 **Project Structure**

```
EvilBotDef1/
├── src/main.cpp                    # Complete source code
├── platformio.ini                  # Build configuration
├── FINAL_M5BURNER_RELEASE/         # Ready-to-flash binaries
│   ├── EvilBotDef1_ParasitePortalKiller.bin
│   ├── manifest.json
│   └── README_M5BURNER.md
├── M5Burner_Package/               # M5Burner files
├── Evil-Face-WITH-DEFENDER.ino    # Arduino IDE version
└── README.md                       # This file
```

---

## 🎮 **Operation**

### **Auto-Start Mode:**
- **Powers on directly into Defender Mode** (no setup required)
- **Immediately starts scanning** for evil portals
- **Face shows hunting expressions** during operation

### **Button Controls:**
- **Short Press** - Toggle between Defender and Karma modes
- **Long Press** - Manual scan for threats (in Defender mode)
- **No Press Needed** - Fully automatic operation

### **Serial Monitoring:**
```bash
pio device monitor --port /dev/ttyACM0 --baud 115200
```

---

## 🐛 **Troubleshooting**

### **Device Not Scanning:**
- Check serial output at 115200 baud for debug info
- Ensure WiFi networks are present and open
- Verify device is in Defender mode (check face expression)

### **No Evil Portals Detected:**
- Device only targets open (unencrypted) WiFi networks
- Encrypted networks are ignored as potentially legitimate
- Check whitelist in code if known networks being skipped

### **Build Issues:**
- Ensure M5Stack-Avatar library is installed correctly
- Use ESP32-S3 board selection in Arduino IDE
- Check PlatformIO platform version compatibility

---

## 📈 **Future Enhancements**

- 🎵 **Audio feedback** during attacks
- 📊 **Statistics display** on face 
- 🌐 **Web interface** for remote monitoring
- ⚙️ **Configurable settings** via web UI
- 🎨 **More face expressions** and animations
- 📱 **Mobile app integration**

---

## 🤝 **Contributing**

Contributions welcome! Please:
1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

---

## 📄 **License**

This project builds upon the original Evil-M5 projects by 7h30th3r0n3. Please respect the original authors' licensing terms and use this tool responsibly for defensive security purposes only.

---

<div align="center">

### 🛡️ **Protect The Innocent. Destroy The Evil. Stay Adorable.** 🛡️

*Made with 💖 by the community, for the community*

**Built on the foundation of [Evil-M5](https://github.com/7h30th3r0n3) projects**

</div>