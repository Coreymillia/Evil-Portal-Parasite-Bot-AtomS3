# Changelog

All notable changes to EvilBotDef1 will be documented in this file.

## [1.0.0] - 2024-10-26

### 🎉 Initial Release - "The Little Parasite Portal Killer"

#### ✨ Added
- **Adorable M5Avatar parasite face** with full expression system
- **Auto-boot Defender Mode** - starts hunting portals immediately on power-on
- **Aggressive open WiFi detection** - targets all unencrypted networks as suspicious
- **Enhanced KILLERBS1 attack method** with 300 spam requests per portal
- **Real-time scanning** every 15 seconds for continuous protection
- **Interactive personality** - motion reactive, expression cycling, victory dances
- **Serial debugging** with detailed operational logging at 115200 baud
- **Multi-endpoint attacks** targeting 6 different portal endpoints
- **Smart whitelisting** to avoid known legitimate networks
- **M5Burner integration** with complete merged binary package

#### 🛡️ Defense Features
- **50 spam bursts per portal** with proven "Caught Ya Slippin" credentials
- **6 attack endpoints** per burst: /login, /post, /creds, /ssid, /, /captive
- **30 connection retry attempts** for persistent portal destruction
- **500ms attack timing** for optimal overwhelming speed
- **Automatic portal detection** with no user interaction required

#### 🤖 Parasite Personality
- **Expression system**: Happy, Sad, Sleepy, Doubt, Neutral, Angry
- **Scanning mode**: Suspicious doubt expression while hunting
- **Attack mode**: Angry expression with spinning animations
- **Victory mode**: Happy spinning celebrations after successful attacks
- **Motion reactive**: Gets angry when shaken or moved
- **Speech bubbles**: Shows current thoughts and status

#### 📦 Distribution
- **PlatformIO project** with complete source code
- **Arduino IDE compatibility** with .ino file
- **M5Burner package** with merged binary ready for community upload
- **GitHub release** with comprehensive documentation

#### 🏆 Credits
- Built on foundation of Evil-M5 projects by **7h30th3r0n3**
- Uses M5Stack-Avatar library by **meganetaaan**
- Enhanced with defense capabilities by **DefenseTeam**
- Inspired by KILLERBS1 attack methodology

#### ⚖️ Legal
- **Defensive security purpose only** - protects users from credential theft
- **Educational and research tool** for understanding captive portal vulnerabilities
- **Compliant usage required** - users must follow local laws and regulations
- **Ethical guidelines** - designed to overwhelm malicious portals, not legitimate networks

### 🔍 Technical Details
- **Platform**: ESP32-S3 (M5Stack AtomS3)
- **Flash usage**: 871KB (26.1% of 8MB)
- **RAM usage**: 47KB (14.3% of 327KB)
- **Libraries**: M5Unified v0.1.17, M5GFX v0.1.17, M5Stack-Avatar v0.10.0
- **Build system**: PlatformIO with ESP32 platform v5.3.0

### 🧪 Testing
- **User confirmed working** - operational testing completed
- **M5Burner binary verified** - merged firmware flashes correctly
- **Portal detection confirmed** - successfully identifies and attacks evil portals
- **Face animations verified** - all expressions and reactions working
- **Serial debugging tested** - full operational visibility confirmed

---

## Planned Future Releases

### [1.1.0] - Audio Feedback
- Add sound effects during scanning and attacks
- Victory sounds for successful portal destruction
- Audio alerts for threat detection

### [1.2.0] - Enhanced Statistics  
- Display attack counter on face
- Show portal destruction statistics
- Historical data tracking

### [1.3.0] - Configuration Interface
- Web-based configuration portal
- Adjustable scan timing and whitelist
- Remote monitoring capabilities

---

*This changelog follows [Keep a Changelog](https://keepachangelog.com/) format.*